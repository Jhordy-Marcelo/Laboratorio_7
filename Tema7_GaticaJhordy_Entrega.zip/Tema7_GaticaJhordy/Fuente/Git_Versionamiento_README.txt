VERSIONAMIENTO SUGERIDO (EJECUTAR EN LA CARPETA DEL PROYECTO)
git init
git add .
git commit -m "docs: establece baseline BL-1.0 y matriz de trazabilidad"
git tag BL-1.0
git switch -c feature/CR-001-validacion-disponibilidad
git add .
git commit -m "feat: incorpora validacion de disponibilidad de habitaciones"
git switch main
git merge feature/CR-001-validacion-disponibilidad
git tag v1.1
git log --oneline --decorate

Para publicar remoto, configura URL real:
git remote add origin URL_DE_TU_REPOSITORIO
git push -u origin main --tags

Estos comandos son instrucciones; no se ha creado ni publicado repositorio remoto.
